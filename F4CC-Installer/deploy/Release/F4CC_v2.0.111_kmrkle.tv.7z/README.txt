Fallout 4 - Crowd Control MOD
=============================                                                                          |

Discover the ultimate Fallout 4 Crowd Control MOD, an innovative addition that revolutionizes your 
streaming experience by allowing viewers to actively participate in your gameplay. Immerse your 
community in the heart of your Wasteland adventures with real-time interaction and unpredictable 
excitement.

Requirements
------------
- CrowdControl (by Warp World Inc.) software: https://crowdcontrol.live/
- F4SE MOD: https://f4se.silverlock.org/

Installation
------------
For help with installation see: https://f4cc.kmrkle.tv/installation
